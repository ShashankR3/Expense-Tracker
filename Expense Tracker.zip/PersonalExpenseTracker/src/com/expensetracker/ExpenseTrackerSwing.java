package com.expensetracker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ExpenseTrackerSwing extends JFrame {
    private static final long serialVersionUID = 1L;
    private ArrayList<Expense> expenses;
    private JTable expenseTable;
    private DefaultTableModel tableModel;
    private JTextField dateField, descriptionField, amountField;
    private JLabel totalLabel;

    public ExpenseTrackerSwing() {
        expenses = ExpenseStorage.loadExpenses();  // Load saved expenses

        setTitle("Expense Tracker");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel for adding expenses
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        dateField = new JTextField(10);
        descriptionField = new JTextField(20);
        amountField = new JTextField(10);

        JButton addButton = new JButton("Add Expense");
        JButton removeButton = new JButton("Remove Expense");

        inputPanel.add(new JLabel("Date (YYYY-MM-DD):"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("Description:"));
        inputPanel.add(descriptionField);
        inputPanel.add(new JLabel("Amount:"));
        inputPanel.add(amountField);
        inputPanel.add(addButton);
        inputPanel.add(removeButton);

        // Table for displaying expenses
        String[] columns = {"Date", "Description", "Amount"};
        tableModel = new DefaultTableModel(columns, 0);
        expenseTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(expenseTable);

        // Label for total expenses
        totalLabel = new JLabel("Total Expenses: $0.00");

        // Add components to frame
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(totalLabel, BorderLayout.SOUTH);

        // Action listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addExpense();
            }
        });

        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeExpense();
            }
        });

        updateTable();
    }

    private void addExpense() {
        try {
            String date = dateField.getText();
            String description = descriptionField.getText();
            double amount = Double.parseDouble(amountField.getText());

            if (amount < 0) {
                JOptionPane.showMessageDialog(this, "Amount cannot be negative!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Expense expense = new Expense(date, description, amount);
            expenses.add(expense);
            ExpenseStorage.saveExpenses(expenses);
            updateTable();
            clearFields();
            updateTotalExpenses();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid amount!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeExpense() {
        int selectedRow = expenseTable.getSelectedRow();
        if (selectedRow != -1) {
            expenses.remove(selectedRow);
            ExpenseStorage.saveExpenses(expenses);
            updateTable();
            updateTotalExpenses();
        } else {
            JOptionPane.showMessageDialog(this, "Please select an expense to remove.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTable() {
        tableModel.setRowCount(0); // Clear the table
        for (Expense expense : expenses) {
            tableModel.addRow(new Object[]{expense.getDate(), expense.getDescription(), expense.getAmount()});
        }
    }

    private void updateTotalExpenses() {
        double total = 0;
        for (Expense expense : expenses) {
            total += expense.getAmount();
        }
        totalLabel.setText("Total Expenses: $" + total);
    }

    private void clearFields() {
        dateField.setText("");
        descriptionField.setText("");
        amountField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ExpenseTrackerSwing frame = new ExpenseTrackerSwing();
            frame.setVisible(true);
        });
    }
}
